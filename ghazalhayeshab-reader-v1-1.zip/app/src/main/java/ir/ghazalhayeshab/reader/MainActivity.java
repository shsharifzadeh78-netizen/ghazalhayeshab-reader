package ir.ghazalhayeshab.reader;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 32, 32, 32);
        root.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("غزل‌های شب");
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("نسخهٔ خواننده\n\nدفتر غزل‌های شب به‌زودی اینجا خواهد بود.");
        subtitle.setTextSize(18);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 28, 0, 0);

        root.addView(title);
        root.addView(subtitle);

        setContentView(root);
    }
}
