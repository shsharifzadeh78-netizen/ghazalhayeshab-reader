plugins {
    id("com.android.application")
}

android {
    namespace = "ir.ghazalhayeshab.reader"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.ghazalhayeshab.reader"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
